import java.util.*;

public class Component1 {

	public static String getStrength(String password) {
		int length_Score = 0;
        int variety_Score = 0;
        int Negative_Score = 0;
        int Total_Score = 0;
        String specialChars = "!@#$%^&*()-_+=<>?";
        String Feedback = "";
        String Strength = "";
        boolean hasUpper = false;
        boolean hasLower = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;
        boolean hasConsecNumbers= false;
        boolean hasConsecLetters= false;
        
        if (password.length() >= 12) {
            length_Score = 40;
        } else if (password.length() >=8) {
            length_Score = 20;
            Feedback += "Your password is short. Consider making it 12 characters or more.\n";
        }
        else {
            Feedback += "Your password is too short. Make it 12 characters or more.\n";
        }
                
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            
            if (Character.isUpperCase(c)) 
            	hasUpper = true;
            if (Character.isLowerCase(c)) 
            	hasLower = true;
            if (Character.isDigit(c)) 
            	hasDigit = true;
            if (specialChars.contains(Character.toString(c))) 
            	hasSpecial = true;
        }
        if (hasUpper) 
        	variety_Score += 10;
        else 
        	Feedback += "Add an uppercase letter to strengthen your password.\n";
        if (hasLower) 
        	variety_Score += 10;
        else 
        	Feedback += "Add a lowercase letter to strengthen your password.\n";
        if (hasDigit) 
        	variety_Score += 20;
        else 
        	Feedback += "Add a number to strengthen your password.\n";
        if (hasSpecial) 
        	variety_Score += 20;
        else 
        	Feedback += "Add a special character (!@#$%^&*()-_+=<>?) to strengthen your password.\n";
        
        for (int i = 0; i < password.length() - 2; i++) {  
            if (Character.isDigit(password.charAt(i))) {
                int current = Character.getNumericValue(password.charAt(i));
                int increasingNext = current + 1;
                int decreasingNext = current - 1;
                int countInc = 1;
                int countDec = 1;
                for (int j = i + 1; j < password.length(); j++) {
                    if (Character.isDigit(password.charAt(j))) {
                        if (Character.getNumericValue(password.charAt(j)) == increasingNext) {
                            countInc++;
                            increasingNext++;
                        }
                        else if (Character.getNumericValue(password.charAt(j)) == decreasingNext) {
                            countDec++;
                            decreasingNext--;
                        } 
                        else 
                            break;
                    }
                    if (countInc >= 3 || countDec >= 3) {
                        hasConsecNumbers = true;
                        break;
                    }
                }
                if (hasConsecNumbers) 
                	break;
            }
        }

        for (int i = 0; i < password.length() - 2; i++) { 
            if (Character.isLetter(password.charAt(i))) {
                char current = password.charAt(i);
                char increasingNext = (char) (current + 1);
                char decreasingNext = (char) (current - 1);
                int countInc = 1;
                int countDec = 1;
                for (int j = i + 1; j < password.length(); j++) {
                    if (Character.isLetter(password.charAt(j))) {
                        if (password.charAt(j) == increasingNext) {
                            countInc++;
                            increasingNext++;
                        }
                        else if (password.charAt(j) == decreasingNext) {
                            countDec++;
                            decreasingNext--;
                        } 
                        else
                            break;
                    }
                    if (countInc >= 3 || countDec >= 3) {
                        hasConsecLetters = true;
                        break;
                    }
                }
                if (hasConsecLetters) 
                	break;
            }
        }
        
        if (hasConsecNumbers) {
        	Negative_Score -= 30; 
        	Feedback += "Avoid using consecutive numbers like '123' or '321' as they are easier to guess.\n";
        }
    	if (hasConsecLetters) {
        	Negative_Score -= 30;
        	Feedback += "Avoid using consecutive letters like 'abc' or 'cba' as they are easier to guess.\n";
    	}
    	    	
    	for (int i = 0; i < password.length() - 2; i++) {
    	    if (password.charAt(i) == password.charAt(i + 1) && password.charAt(i) == password.charAt(i + 2)) {
    	        Negative_Score -= 20;
    	        Feedback += "Avoid repeating the same character multiple times like 'aaa' or '111'.\n";
    	        break;
    	    }
    	}
                
        Total_Score = variety_Score + length_Score + Negative_Score;
                
        if (Total_Score >= 80) 
            Strength = "Password Strength: Very Strong\n";
        else if (Total_Score >= 60) 
        	Strength = "Password Strength: Strong\n";
        else if (Total_Score >= 40)
        	Strength = "Password Strength: Moderate\n";
        else if (Total_Score >= 10)
            Strength = "Password Strength: Weak\n";
        else 
        	Strength = "Password Strength: Very Weak\n";
        	
        return Strength + Feedback;
	
	}
	public static void main(String[] args) {
		Scanner SC = new Scanner(System.in);
		System.out.println("Enter your password: ");
        String Password = SC.nextLine();
        String Feedback = getStrength(Password);
        System.out.println(Feedback);
        SC.close();
	}


}
