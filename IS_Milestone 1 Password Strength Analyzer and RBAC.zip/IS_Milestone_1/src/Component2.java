import java.util.ArrayList;
import java.util.Scanner;

public class Component2 {

	ArrayList<String> names = new ArrayList<>();

public Component2( ) {
	this.names=new ArrayList<>();
	names.add("Customer1");
	names.add("Customer2");
	names.add("Customer3");
	names.add("Admin");
	names.add("manager");
	names.add("CustomerService1");
	names.add("CustomerService2");
	}

public String login (String UN ,String P ) {
	String s="";
	if (UN.contains("Customer")) {
		s="Your role is : Customer"+
	"\n" +"The procedures you are allowed to do are : Create new order , View available products" ;
	} 
	else if (UN.contains("Admin")) {
		s="Your role is : Admin"+ 
	"\n"+"The procedures you are allowed to do are : Check website errors";
	}
	else if (UN.contains("manager")) {
		s="Your role is : Manager"+ 
	"\n" +"The procedures you are allowed to do are : Create new order, "
				+ "Check available stock, View payments details of all customers, View Available Products, Update Products list, Delete Products, View Order details, Check website errors"; 
	}
	else if (UN.contains("CustomerService")) {
		s="Your role is : Customer Service"+ 
	"\n" +"The procedures you are allowed to do are : View Available Products, View Order details"; 
	}
	else {
		s="you role is unspecified, Please try again using either Customer, Admin, Manager or Customer Service ";
	}
	return s;
}

public String View_Available_Products() {
	
	return "Available products are : Product 1  Price 10 , Product 2  Price 20, Product 3  Price 30, Product 4 Price 40"; 
	
}
	
public static void main (String [] args) {
	Component2 c =new Component2();
	
	System.out.println("Please login using your username and password ");
	System.out.println("Username : ");
	Scanner User =new Scanner (System.in);
	String UserName=User.nextLine();
	
	System.out.println("Password : ");
	Scanner Pass =new Scanner (System.in);
	String Password=Pass.nextLine();
	
	System.out.println(c.login(UserName,Password));
	
	System.out.println("Please specify what you are going to do ");
	Scanner proc =new Scanner (System.in);
	String Procedure=proc.nextLine();
	
	if (UserName.contains("Customer")) {
		if (Procedure.equalsIgnoreCase("Create new order")|| Procedure.equalsIgnoreCase("View available products" )){
			System.out.println("You are authorized");
		}
		else {
			System.out.println("You are not authorized, Please choose one of your allowed procedures");
		}
	} else if (UserName.contains("Admin")) {
		if (Procedure.equalsIgnoreCase("Check website errors")) {
			System.out.println("You are authorized");
		}
		else {
			System.out.println("You are not authorized, Please choose one of your allowed procedures");
		}
	} else if (UserName.contains("manager")) {
		System.out.println("You are authorized");
	}
	else if (UserName.contains("CstomerService")) {
		if (Procedure.equalsIgnoreCase("View Available Products") || Procedure.equalsIgnoreCase("View Order details")) {
			System.out.println("You are authorized");
		}
		else {
			System.out.println("You are not authorized, Please choose one of your allowed procedures");
		}
	}
	else {
		System.out.println("You are not authorized to access the system :( ");
	}
	
	 if ((UserName.contains("Customer")||UserName.contains("CstomerService")||UserName.contains("manager") )&& Procedure.equalsIgnoreCase("View available products")){
		 System.out.println(c.View_Available_Products());
	 }
	
	User.close();
	Pass.close();
	proc.close();
 
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
