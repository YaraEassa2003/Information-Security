import java.util.Scanner;

public class PlayfairCipher {
	public static char[][] matrix = new char[5][5];
    
    public static void createPlayfairMatrix(String Keyword) {
    	String alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ";
    	String uniqueCharacters = "";
        Keyword = Keyword.toUpperCase();
        
        for (int i = 0; i < Keyword.length(); i++) {
            char c = Keyword.charAt(i);
            if (c == 'J') {
            	c = 'I'; 
            }
            if (!uniqueCharacters.contains(String.valueOf(c))) {
                uniqueCharacters += c;
                alphabet = alphabet.replace(String.valueOf(c), ""); 
            }
        }
        
        uniqueCharacters += alphabet;
        
        int Count = 0; 
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                matrix[i][j] = uniqueCharacters.charAt(Count++);
            }
        }
        
        System.out.println("Playfair Matrix:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
    public static String prepareMessage(String Message) {
    	String prepared = "";
        Message = Message.toUpperCase().replaceAll(" ", ""); 

        for (int i = 0; i < Message.length(); ) {
            char c = Message.charAt(i); 
            
            if (c == 'J') {
                c = 'I';
            }
            prepared += c;

            if (i + 1 < Message.length() && c == Message.charAt(i + 1)) {
                prepared += "X";
                i++;     
            } 
            	else {
            		if (i + 1 < Message.length()) {
            			char nextC = Message.charAt(i + 1);
                        if (nextC == 'J') {
                            nextC = 'I';
                        }
                        prepared += nextC;  
                    }
            		i += 2; 
            	}
        	}
        if (prepared.length() % 2 != 0) {
            prepared += "Z";
        }
    	return prepared;
    }
	
    public static String encryptMessage(String Message) {
    	Message = prepareMessage(Message);
        String encrypted = "";
        
        for (int i = 0; i < Message.length(); i += 2) {
            char c1 = Message.charAt(i);
            char c2 = Message.charAt(i + 1);

            int row_c1=0;
            int col_c1=0; 
            int row_c2=0;
            int col_c2=0; 
            
            for (int row = 0; row < 5; row++) {
                for (int col = 0; col < 5; col++) {
                    if (matrix[row][col] == c1) {
                        row_c1 = row;
                        col_c1 = col;
                    } 
                    else if (matrix[row][col] == c2) {
                        row_c2 = row;
                        col_c2 = col;
                    }
                }
            }
            
            if (row_c1 == row_c2) {
            	col_c1 = col_c1 + 1;
                if (col_c1 > 4) {
                    col_c1 = 0;
                }

                col_c2 = col_c2 + 1;
                if (col_c2 > 4) {
                    col_c2 = 0;
                }
                encrypted += matrix[row_c1][col_c1];
                encrypted += matrix[row_c2][col_c2];
            } 
            
            else if (col_c1 == col_c2) {
            	row_c1 = row_c1 + 1;
                if (row_c1 > 4) {
                    row_c1 = 0;
                }

                row_c2 = row_c2 + 1;
                if (row_c2 > 4) {
                    row_c2 = 0; 
                }
                encrypted += matrix[row_c1][col_c1];
                encrypted += matrix[row_c2][col_c2];
            } 
            else {
                encrypted += matrix[row_c1][col_c2];
                encrypted += matrix[row_c2][col_c1];
            }
        }
        return encrypted;   
    } 
    
    public static void main(String[] args) {
		Scanner SC = new Scanner(System.in);
		System.out.println("Enter the Message you Want to Encrypt: ");
        String Message = SC.nextLine();
        System.out.println("Enter the Keyword to be Used for Encryption: ");
        String Keyword = SC.nextLine();
        createPlayfairMatrix(Keyword);
        String s = prepareMessage(Message);
        System.out.print("Prepared Text: "+s+ "\n");
        String encryptedMessage = encryptMessage(Message);
        System.out.println("Encrypted message: " + encryptedMessage);
        SC.close();
	}

}
