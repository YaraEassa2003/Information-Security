import java.util.Scanner;

public class XOR_Encryption {

	private static String extendKeyword(String keyword, int length) {
	    String extendedKey = "";
	    for (int i = 0; i < length; i++) {
	        extendedKey += keyword.charAt(i % keyword.length());
	    }
	    return extendedKey;  
	}
	
	 public static int[] toAsciiArray(String text) {
	        int[] asciiArray = new int[text.length()];
	        for (int i = 0; i < text.length(); i++) {
	            asciiArray[i] = (int) text.charAt(i);
	        }
	        return asciiArray;
	    }

//	 public static String[] toBinaryStringArray(int[] asciiArray) {
//	        String[] binaryArray = new String[asciiArray.length];
//	        for (int i = 0; i < asciiArray.length; i++) {
//	            String binaryString = Integer.toBinaryString(asciiArray[i]);
//	            while (binaryString.length() < 8) {
//	                binaryString = "0" + binaryString;  // Add leading zeros to make it 8 bits
//	            }
//	            binaryArray[i] = binaryString;
//	        }
//	        return binaryArray;
//	    }
	 
	
	    public static String encrypt(String plaintext, String key) {
	        String extendedKey = extendKeyword(key, plaintext.length());

	        int[] plaintextAscii = toAsciiArray(plaintext);
	        int[] keyAscii = toAsciiArray(extendedKey); 

	        int[] xorResultAscii = new int[plaintextAscii.length];
	        for (int i = 0; i < plaintextAscii.length; i++) {
	            xorResultAscii[i] = plaintextAscii[i] ^ keyAscii[i];
	        }

	        String encryptedText = "";
	        for (int i = 0; i < xorResultAscii.length; i++) {
	            encryptedText += xorResultAscii[i]; 
	        }

	        return encryptedText;
	    }
	 
	    public static void main(String[] args) {
		    Scanner Plaintext = new Scanner(System.in);
	        Scanner key= new Scanner(System.in);
	        
	    
	        System.out.println("Please enter the text you want to encrypt: ");
	        String plaintext = Plaintext.nextLine();

	        System.out.println("Please enter the keyword: ");
	        String keyword = key.nextLine();

	       
	        String encryptedText = encrypt(plaintext, keyword);
	        System.out.println("Encrypted Text: " + encryptedText);

	        Plaintext.close();
	        key.close();
	    
	}
	
	
}
