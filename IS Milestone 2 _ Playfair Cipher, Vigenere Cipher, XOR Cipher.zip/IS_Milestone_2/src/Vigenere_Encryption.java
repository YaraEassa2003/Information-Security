import java.util.Scanner;
public class Vigenere_Encryption {
	
	
	
    private static final char[][] VIGENERE_TABLE = generateVigenereTable();

   
    private static char[][] generateVigenereTable() {
        char[][] table = new char[26][26];
        for (int i = 0; i < 26; i++) {
            for (int j = 0; j < 26; j++) {
                table[i][j] = (char) ('A' + (i + j) % 26);
            }
        }
        return table;
    }

    public static void printVigenereTable() {
        System.out.print("    ");
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            System.out.print(ch + " ");
        }
        System.out.println();
        
        for (int i = 0; i < 26; i++) {
            System.out.print((char) ('A' + i) + " | ");
            for (int j = 0; j < 26; j++) {
                System.out.print(VIGENERE_TABLE[i][j] + " ");
            }
            System.out.println();
        }
    }

    
    private static String extendKeyword(String keyword, int length) {
        String extendedKey = "";
        for (int i = 0; i < length; i++) {
            extendedKey += keyword.charAt(i % keyword.length());
        }
       
        return extendedKey.toUpperCase();
    }

    
    public static String encrypt(String plaintext, String keyword) {
        plaintext = plaintext.toUpperCase();
        plaintext = plaintext.replace(" ", ""); 
        keyword = extendKeyword(keyword, plaintext.length()); 
        
        System.out.println("Pl "+plaintext);
        System.out.println("keyword "+keyword);
        String encryptedText = "";

        int keyIndex = 0; 

        for (int i = 0; i < plaintext.length(); i++) {
            char plainChar = plaintext.charAt(i);

            if (Character.isLetter(plainChar)) {
                int row = keyword.charAt(keyIndex) - 'A'; 
                int col = plainChar - 'A';                 
                encryptedText += VIGENERE_TABLE[row][col];
                keyIndex++; 
            }
        }
        return encryptedText;
    }

    public static void main(String[] args) {
        Scanner Plaintext = new Scanner(System.in);
        Scanner key= new Scanner(System.in);
        
       // printVigenereTable();

   
        System.out.println("Please enter the text you want to encrypt: ");
        String plaintext = Plaintext.nextLine();

        System.out.println("Please enter the keyword: ");
        String keyword = key.nextLine();

       
        String encryptedText = encrypt(plaintext, keyword);
        System.out.println("Encrypted Text: " + encryptedText);

        Plaintext.close();
        key.close();
    }
}

	


